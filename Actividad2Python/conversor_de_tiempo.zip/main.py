from proyecto2 import proyecto2

x=int(input("Digite los segundos a convertir: "))
y=input("Digite la unidad destino (minutos, horas, días): ")

print(proyecto2.conversor_de_tiempo(x,y))